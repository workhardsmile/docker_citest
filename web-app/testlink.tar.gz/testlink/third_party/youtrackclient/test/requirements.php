<?php
/**
 * Include the requirements for testing.
 */
require_once("src/youtrackclient.php");
