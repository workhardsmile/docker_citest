// EN lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'The changes you made will be lost if you navigate away from this page.'
});
