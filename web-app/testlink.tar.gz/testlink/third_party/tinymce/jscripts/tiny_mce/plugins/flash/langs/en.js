// UK lang variables

tinyMCE.addToLang('flash',{
title : 'Insert / edit Flash Movie',
desc : 'Insert / edit Flash Movie',
file : 'Flash-File (.swf)',
size : 'Size',
list : 'Flash files',
props : 'Flash properties',
general : 'General'
});
