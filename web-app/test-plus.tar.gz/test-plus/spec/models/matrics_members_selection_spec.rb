require 'spec_helper'

describe MatricsMembersSelection do
  pending "add some examples to (or delete) #{__FILE__}"
end
