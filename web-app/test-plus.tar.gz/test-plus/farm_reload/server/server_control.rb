require "rubygems"
require "daemons"

Daemons.run('server.rb')