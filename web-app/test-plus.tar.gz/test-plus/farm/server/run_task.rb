class RoundTask
  attr_accessor :id
  attr_accessor :command
  attr_accessor :status
  attr_accessor :priority
  attr_accessor :market
  attr_accessor :capability
end
