Rails.application.config.generators do |g|
  g.template_engine :haml
end