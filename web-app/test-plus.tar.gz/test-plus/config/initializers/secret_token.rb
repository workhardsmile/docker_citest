# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
TestPlusWebMain::Application.config.secret_token = '59a7310d5787f10b24f50d6c78fb72db507175a5ac0b1deff64e4bb9010cc596a93e25bdcdb6bab2558d1721cd0bd4285946acc18a3145fecc2b19a82f508688'
