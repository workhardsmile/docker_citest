class ProjectBranchScript < ActiveRecord::Base
  belongs_to :project
end
