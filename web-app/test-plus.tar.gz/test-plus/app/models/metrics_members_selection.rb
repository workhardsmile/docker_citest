class MetricsMembersSelection < ActiveRecord::Base
end
