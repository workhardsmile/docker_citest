class ImportTestlinkConfig < ActiveRecord::Base
end
