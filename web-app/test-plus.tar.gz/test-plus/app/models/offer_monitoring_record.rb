class OfferMonitoringRecord < ActiveRecord::Base
end
