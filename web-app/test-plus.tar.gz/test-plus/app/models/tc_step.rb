class TcStep < ActiveRecord::Base
  belongs_to :test_case
end
