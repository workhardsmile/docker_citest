module Admin::CiMappingsHelper
end
