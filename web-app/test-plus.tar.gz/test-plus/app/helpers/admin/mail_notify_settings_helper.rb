module Admin::MailNotifySettingsHelper
end
