module CiMappingsHelper
end
