require 'test_helper'

class OldTestCasesHelperTest < ActionView::TestCase
end
