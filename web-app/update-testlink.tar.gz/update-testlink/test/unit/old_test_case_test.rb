require 'test_helper'

class OldTestCaseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
