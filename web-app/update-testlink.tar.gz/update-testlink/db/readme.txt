(1) TestLink -> Define Custom Fields -> 
automation_script,Automation Script,string,,test specification,Test Case
case_status,Automation Status,radio,Automatable|Automated|Not Ready for Automation|Update Needed,test specification,Test Case
(2) TestLink -> Assign Custom Fields 
