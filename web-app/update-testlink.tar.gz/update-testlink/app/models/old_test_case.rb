class OldTestCase < ActiveRecord::Base
  #paginates_per 50
end
