# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
UpdateTestlink::Application.config.secret_token = '42f4f294741caa18d709a7adfa4c95b84d7563c9c11dd921e509bcd9e4be21bbe14911231696c9059ecd2e03f5f1ea6346c7254c9d2ea83c4b0e0031801fd369'
