require 'test_helper'

class UploadControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
