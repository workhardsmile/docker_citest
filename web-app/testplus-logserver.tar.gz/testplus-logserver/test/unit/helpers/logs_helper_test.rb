require 'test_helper'

class LogsHelperTest < ActionView::TestCase
end
