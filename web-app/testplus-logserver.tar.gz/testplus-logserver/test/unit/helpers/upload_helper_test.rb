require 'test_helper'

class UploadHelperTest < ActionView::TestCase
end
