<?php /* Smarty version Smarty-3.1.13, created on 2016-09-05 11:34:41
         compiled from "/var/www/testlink-1.9.14/gui/templates/inc_show_hide_mgmt.tpl" */ ?>
<?php /*%%SmartyHeaderCode:172775950557cce7d1f16033-75955645%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9ce0ac8b80a5de8a2c1a792652a15e70afbbd34b' => 
    array (
      0 => '/var/www/testlink-1.9.14/gui/templates/inc_show_hide_mgmt.tpl',
      1 => 1427533465,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '172775950557cce7d1f16033-75955645',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'show_hide_container_draw' => 0,
    'show_hide_container_class' => 0,
    'show_hide_container_view_status_id' => 0,
    'show_hide_container_id' => 0,
    'show_hide_container_title' => 0,
    'show_hide_container_html' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_57cce7d2122553_18034347',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57cce7d2122553_18034347')) {function content_57cce7d2122553_18034347($_smarty_tpl) {?>
<?php $_smarty_tpl->tpl_vars['show_hide_container_draw'] = new Smarty_variable((($tmp = @$_smarty_tpl->tpl_vars['show_hide_container_draw']->value)===null||$tmp==='' ? false : $tmp), null, 0);?>
<?php $_smarty_tpl->tpl_vars['show_hide_container_class'] = new Smarty_variable((($tmp = @$_smarty_tpl->tpl_vars['show_hide_container_class']->value)===null||$tmp==='' ? "exec_additional_info" : $tmp), null, 0);?>



<input type='hidden' id="<?php echo $_smarty_tpl->tpl_vars['show_hide_container_view_status_id']->value;?>
"
         name="<?php echo $_smarty_tpl->tpl_vars['show_hide_container_view_status_id']->value;?>
"  value="0" />

<div class="x-panel-header x-unselectable">
	<div class="x-tool x-tool-toggle" style="background-position:0 -75px; float:left;"
		onclick="show_hide('<?php echo $_smarty_tpl->tpl_vars['show_hide_container_id']->value;?>
',
	              '<?php echo $_smarty_tpl->tpl_vars['show_hide_container_view_status_id']->value;?>
',
	              document.getElementById('<?php echo $_smarty_tpl->tpl_vars['show_hide_container_id']->value;?>
').style.display=='none')">
	</div>
	<span style="padding:2px;"><?php echo $_smarty_tpl->tpl_vars['show_hide_container_title']->value;?>
</span>
</div>

<?php if ($_smarty_tpl->tpl_vars['show_hide_container_draw']->value){?>
	<div id="<?php echo $_smarty_tpl->tpl_vars['show_hide_container_id']->value;?>
" class="<?php echo $_smarty_tpl->tpl_vars['show_hide_container_class']->value;?>
">
		<?php echo $_smarty_tpl->tpl_vars['show_hide_container_html']->value;?>

	</div>
<?php }?><?php }} ?>