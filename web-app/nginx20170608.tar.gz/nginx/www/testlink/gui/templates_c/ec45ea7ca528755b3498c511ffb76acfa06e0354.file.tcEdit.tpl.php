<?php /* Smarty version Smarty-3.1.13, created on 2017-04-12 09:53:20
         compiled from "/var/www/testlink/gui/templates/testcases/tcEdit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:149640817258ed8890642692-06361198%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ec45ea7ca528755b3498c511ffb76acfa06e0354' => 
    array (
      0 => '/var/www/testlink/gui/templates/testcases/tcEdit.tpl',
      1 => 1491911777,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '149640817258ed8890642692-06361198',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'gui' => 0,
    'opt_cfg' => 0,
    'labels' => 0,
    'tlCfg' => 0,
    'warning_edit_msg' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_58ed88906fe059_51816347',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58ed88906fe059_51816347')) {function content_58ed88906fe059_51816347($_smarty_tpl) {?>

<?php echo lang_get_smarty(array('var'=>"labels",'s'=>"warning,warning_empty_tc_title,btn_save,warning_estimated_execution_duration_format,
             version,title_edit_tc,cancel,warning_unsaved"),$_smarty_tpl);?>


<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>'yes','jsValidate'=>"yes",'editorType'=>$_smarty_tpl->tpl_vars['gui']->value->editorType), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("inc_del_onclick.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<script language="JavaScript" src="gui/javascript/OptionTransfer.js" type="text/javascript"></script>
<script language="JavaScript" src="gui/javascript/expandAndCollapseFunctions.js" type="text/javascript"></script>
<script language="javascript" src="gui/javascript/ext_extensions.js" type="text/javascript"></script>
<script language="javascript" src="gui/javascript/tcase_utils.js" type="text/javascript"></script>

<?php $_smarty_tpl->tpl_vars['opt_cfg'] = new Smarty_variable($_smarty_tpl->tpl_vars['gui']->value->opt_cfg, null, 0);?>
<script type="text/javascript" language="JavaScript">
var <?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
 = new OptionTransfer("<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->from->name;?>
","<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->to->name;?>
");
<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
.saveRemovedLeftOptions("<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
_removedLeft");
<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
.saveRemovedRightOptions("<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
_removedRight");
<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
.saveAddedLeftOptions("<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
_addedLeft");
<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
.saveAddedRightOptions("<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
_addedRight");
<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
.saveNewLeftOptions("<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
_newLeft");
<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
.saveNewRightOptions("<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
_newRight");
</script>

<script type="text/javascript">
var warning_empty_testcase_name = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning_empty_tc_title'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";
var alert_box_title = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";
var warning_estimated_execution_duration_format = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning_estimated_execution_duration_format'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";


/**
 * validate certain form controls before submitting
 *
 */
function validateForm(the_form)
{
  var status_ok = true;
  
  if (isWhitespace(the_form.testcase_name.value))
  {
    alert_message(alert_box_title,warning_empty_testcase_name);
    selectField(the_form,'testcase_name');
    return false;
  }

  var val2check = the_form.estimated_execution_duration.value;
  if( isNaN(val2check) || /^\s+$/.test(val2check.trim()))
  {
    alert_message(alert_box_title,warning_estimated_execution_duration_format);
    return false;
  }

  var cf_designTime = document.getElementById('cfields_design_time');
  if (cf_designTime)
  {
    var cfields_container = cf_designTime.getElementsByTagName('input');
    var cfieldsChecks = validateCustomFields(cfields_container);
    if(!cfieldsChecks.status_ok)
    {
      var warning_msg = cfMessages[cfieldsChecks.msg_id];
      alert_message(alert_box_title,warning_msg.replace(/%s/, cfieldsChecks.cfield_label));
      return false;
    }

    cfields_container = cf_designTime.getElementsByTagName('textarea');
    cfieldsChecks = validateCustomFields(cfields_container);
    if(!cfieldsChecks.status_ok)
    {
      var warning_msg = cfMessages[cfieldsChecks.msg_id];
      alert_message(alert_box_title,warning_msg.replace(/%s/, cfieldsChecks.cfield_label));
      return false;
    }
  }
  return Ext.ux.requireSessionAndSubmit(the_form);
}
</script>

<?php if ($_smarty_tpl->tpl_vars['tlCfg']->value->gui->checkNotSaved){?>
  <script type="text/javascript">
  var unload_msg = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning_unsaved'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";
  var tc_editor = "<?php echo $_smarty_tpl->tpl_vars['gui']->value->editorType;?>
";
  </script>
  <script src="gui/javascript/checkmodified.js" type="text/javascript"></script>
<?php }?>
</head>

<body onLoad="<?php echo $_smarty_tpl->tpl_vars['opt_cfg']->value->js_ot_name;?>
.init(document.forms[0]);focusInputField('testcase_name')">
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("tcNew", 'local'); ?>
<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['labels']->value['title_edit_tc'];?>
<?php echo @constant('TITLE_SEP');?>
<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->tc['name'], ENT_QUOTES, 'UTF-8', true);?>

  <?php echo @constant('TITLE_SEP_TYPE3');?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['version'];?>
 <?php echo $_smarty_tpl->tpl_vars['gui']->value->tc['version'];?>
</h1> 

<div class="workBack" style="width:97%;">

<?php if ($_smarty_tpl->tpl_vars['gui']->value->has_been_executed){?>
    <?php echo lang_get_smarty(array('s'=>'warning_editing_executed_tc','var'=>"warning_edit_msg"),$_smarty_tpl);?>

    <div class="messages" align="center"><?php echo $_smarty_tpl->tpl_vars['warning_edit_msg']->value;?>
</div>
<?php }?>

<form method="post" action="lib/testcases/tcEdit.php" name="tc_edit"
      onSubmit="return validateForm(this);">

  <input type="hidden" name="testsuite_id" id="testsuite_id" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->tc['testsuite_id'];?>
" />
  <input type="hidden" name="testcase_id" id="testcase_id" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->tc['testcase_id'];?>
" />
  <input type="hidden" name="tcversion_id" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->tc['id'];?>
" />
  <input type="hidden" name="version" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->tc['version'];?>
" />
  <input type="hidden" name="doAction" value="" />
  <input type="hidden" name="show_mode" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->show_mode;?>
" />
  
  
  <div class="groupBtn">
    <input id="do_update" type="submit" name="do_update" 
           onclick="show_modified_warning=false; doAction.value='doUpdate'" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_save'];?>
" />
    
    <input type="button" name="go_back" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['cancel'];?>
" 
           onclick="show_modified_warning=false; 
                    javascript: <?php if (isset($_smarty_tpl->tpl_vars['gui']->value->cancelActionJS)){?><?php echo $_smarty_tpl->tpl_vars['gui']->value->cancelActionJS;?>
 <?php }else{ ?> history.back() <?php }?>;"/>
  </div>  
  <?php echo $_smarty_tpl->getSubTemplate ("testcases/tcEdit_New_viewer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

  
  
  <div class="groupBtn">
    <input id="do_update_bottom" type="submit" name="do_update" 
           onclick="show_modified_warning=false; doAction.value='doUpdate'" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_save'];?>
" />
    <input type="button" name="go_back_bottom" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['cancel'];?>
" 
           onclick="show_modified_warning=false; 
                    javascript: <?php if (isset($_smarty_tpl->tpl_vars['gui']->value->cancelActionJS)){?><?php echo $_smarty_tpl->tpl_vars['gui']->value->cancelActionJS;?>
 <?php }else{ ?> history.back() <?php }?>;"/>
  </div>  
</form>

<script type="text/javascript" defer="1">
    document.forms[0].testcase_name.focus();
</script>

<?php if (isset($_smarty_tpl->tpl_vars['gui']->value->refreshTree)&&$_smarty_tpl->tpl_vars['gui']->value->refreshTree){?>
  <?php echo $_smarty_tpl->getSubTemplate ("inc_refreshTreeWithFilters.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }?>

</div>
</body>
</html>
<?php }} ?>