<?php /* Smarty version Smarty-3.1.13, created on 2016-09-05 11:13:18
         compiled from "/var/www/testlink-1.9.14/gui/templates/testcases/tcImport.tpl" */ ?>
<?php /*%%SmartyHeaderCode:148239682657cce2ce943ba3-20831496%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c5e99b18918926b2cd1dd39f8ff673a6f903f81c' => 
    array (
      0 => '/var/www/testlink-1.9.14/gui/templates/testcases/tcImport.tpl',
      1 => 1427533465,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '148239682657cce2ce943ba3-20831496',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cfg_section' => 0,
    'gui' => 0,
    'SCRIPT_NAME' => 0,
    'labels' => 0,
    'basehref' => 0,
    'result' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_57cce2ceca7a98_37520875',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57cce2ceca7a98_37520875')) {function content_57cce2ceca7a98_37520875($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/var/www/testlink-1.9.14/third_party/smarty3/libs/plugins/modifier.replace.php';
if (!is_callable('smarty_function_html_options')) include '/var/www/testlink-1.9.14/third_party/smarty3/libs/plugins/function.html_options.php';
?>

<?php echo lang_get_smarty(array('var'=>"labels",'s'=>'file_type,view_file_format_doc,local_file,
             max_size_cvs_file1,max_size_cvs_file2,btn_upload_file,
             duplicate_criteria,action_for_duplicates,testcase,
             action_on_duplicated_name,warning,btn_cancel,title_imp_tc_data'),$_smarty_tpl);?>


<?php $_smarty_tpl->tpl_vars['cfg_section'] = new Smarty_variable(smarty_modifier_replace(basename(basename($_smarty_tpl->source->filepath)),".tpl",''), null, 0);?>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars($_smarty_tpl->tpl_vars['cfg_section']->value, 'local'); ?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>"yes"), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_del_onclick.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</head>
<body>

<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['gui']->value->container_description;?>
<?php echo @constant('TITLE_SEP');?>
<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->container_name, ENT_QUOTES, 'UTF-8', true);?>
</h1>

<div class="workBack">
<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['gui']->value->import_title;?>
</h1>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->resultMap==null){?>
<form method="post" enctype="multipart/form-data" action="<?php echo $_smarty_tpl->tpl_vars['SCRIPT_NAME']->value;?>
">

  <table>
  <tr>
  <td> <?php echo $_smarty_tpl->tpl_vars['labels']->value['file_type'];?>
 </td>
  <td> <select name="importType">
         <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->importTypes),$_smarty_tpl);?>

	     </select>
	<a href=<?php echo $_smarty_tpl->tpl_vars['basehref']->value;?>
<?php echo @constant('PARTIAL_URL_TL_FILE_FORMATS_DOCUMENT');?>
><?php echo $_smarty_tpl->tpl_vars['labels']->value['view_file_format_doc'];?>
</a>
	</td>
	</tr>
	<tr><td><?php echo $_smarty_tpl->tpl_vars['labels']->value['local_file'];?>
 </td>
	    <td><input type="file" name="uploadedFile" 
	                           size="<?php echo $_smarty_tpl->getConfigVariable('FILENAME_SIZE');?>
" maxlength="<?php echo $_smarty_tpl->getConfigVariable('FILENAME_MAXLEN');?>
"/></td>
	</tr>
	<?php if ($_smarty_tpl->tpl_vars['gui']->value->hitOptions!=''){?>
	  <tr><td><?php echo $_smarty_tpl->tpl_vars['labels']->value['duplicate_criteria'];?>
 </td>
	      <td><select name="hit_criteria" id="hit_criteria">
	  			  <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->hitOptions,'selected'=>$_smarty_tpl->tpl_vars['gui']->value->hitCriteria),$_smarty_tpl);?>

	  		    </select>
      </td>
	  </tr>
	<?php }?>

	<?php if ($_smarty_tpl->tpl_vars['gui']->value->actionOptions!=''){?>
	<tr><td><?php echo $_smarty_tpl->tpl_vars['labels']->value['action_for_duplicates'];?>
 </td>
	    <td><select name="action_on_duplicated_name">
				  <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->actionOptions,'selected'=>$_smarty_tpl->tpl_vars['gui']->value->action_on_duplicated_name),$_smarty_tpl);?>

			    </select>
    </td>
	</tr>
	<?php }?>

	</table>
	<p><?php echo $_smarty_tpl->tpl_vars['labels']->value['max_size_cvs_file1'];?>
 <?php echo $_smarty_tpl->tpl_vars['gui']->value->importLimitKB;?>
 <?php echo $_smarty_tpl->tpl_vars['labels']->value['max_size_cvs_file2'];?>
</p>
	<div class="groupBtn">
		<input type="hidden" name="useRecursion" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->useRecursion;?>
" />
		<input type="hidden" name="bIntoProject" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->bIntoProject;?>
" />
		<input type="hidden" name="containerID" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->containerID;?>
" />
		<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->importLimitBytes;?>
" /> 
		<input type="submit" name="UploadFile" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_upload_file'];?>
" />
		<input type="button" name="cancel" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_cancel'];?>
" 
			                   onclick="javascript:history.back();" />
	</div>
</form>
<?php }else{ ?>
  <?php  $_smarty_tpl->tpl_vars['result'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['result']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->resultMap; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['result']->key => $_smarty_tpl->tpl_vars['result']->value){
$_smarty_tpl->tpl_vars['result']->_loop = true;
?>
    <?php echo $_smarty_tpl->tpl_vars['labels']->value['testcase'];?>
 : <b><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['result']->value[0], ENT_QUOTES, 'UTF-8', true);?>
</b> : <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['result']->value[1], ENT_QUOTES, 'UTF-8', true);?>
<br>
  <?php } ?>

  <?php echo $_smarty_tpl->getSubTemplate ("inc_refreshTree.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->bImport>0){?>
	<?php echo $_smarty_tpl->getSubTemplate ("inc_refreshTree.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->file_check['status_ok']==0){?>
  <script type="text/javascript">
  alert_message("<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
","<?php echo strtr($_smarty_tpl->tpl_vars['gui']->value->file_check['msg'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
");
  </script>
<?php }?>  


</div>

</body>
</html><?php }} ?>