<?php /* Smarty version Smarty-3.1.13, created on 2017-02-15 12:11:02
         compiled from "/var/www/testlink-1.9.14/gui/templates/results/testCasesWithoutTester.tpl" */ ?>
<?php /*%%SmartyHeaderCode:178629664358a3d4d60e3d33-18259798%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '28dfccffaaf5a7c620e491850bc9a0aab91fb76a' => 
    array (
      0 => '/var/www/testlink-1.9.14/gui/templates/results/testCasesWithoutTester.tpl',
      1 => 1427533465,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '178629664358a3d4d60e3d33-18259798',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'gui' => 0,
    'matrix' => 0,
    'tableID' => 0,
    'labels' => 0,
    'gsmarty_timestamp_format' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_58a3d4d62b41c4_41119946',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58a3d4d62b41c4_41119946')) {function content_58a3d4d62b41c4_41119946($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/var/www/testlink-1.9.14/third_party/smarty3/libs/plugins/modifier.date_format.php';
?>

<?php echo lang_get_smarty(array('var'=>"labels",'s'=>'no_uncovered_testcases,testproject_has_no_reqspec,
             testproject_has_no_requirements,generated_by_TestLink_on,
             testCasesWithoutTester_info'),$_smarty_tpl);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>"yes"), 0);?>

<?php  $_smarty_tpl->tpl_vars['matrix'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['matrix']->_loop = false;
 $_smarty_tpl->tpl_vars['idx'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->tableSet; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['matrix']->index=-1;
foreach ($_from as $_smarty_tpl->tpl_vars['matrix']->key => $_smarty_tpl->tpl_vars['matrix']->value){
$_smarty_tpl->tpl_vars['matrix']->_loop = true;
 $_smarty_tpl->tpl_vars['idx']->value = $_smarty_tpl->tpl_vars['matrix']->key;
 $_smarty_tpl->tpl_vars['matrix']->index++;
 $_smarty_tpl->tpl_vars['matrix']->first = $_smarty_tpl->tpl_vars['matrix']->index === 0;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']["initializer"]['first'] = $_smarty_tpl->tpl_vars['matrix']->first;
?>
  <?php $_smarty_tpl->tpl_vars['tableID'] = new Smarty_variable($_smarty_tpl->tpl_vars['matrix']->value->tableID, null, 0);?>
  <?php if ($_smarty_tpl->getVariable('smarty')->value['foreach']['initializer']['first']){?>
    <?php echo $_smarty_tpl->tpl_vars['matrix']->value->renderCommonGlobals();?>

    <?php if ($_smarty_tpl->tpl_vars['matrix']->value instanceof tlExtTable){?>
        <?php echo $_smarty_tpl->getSubTemplate ("inc_ext_js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('bResetEXTCss'=>1), 0);?>

        <?php echo $_smarty_tpl->getSubTemplate ("inc_ext_table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

    <?php }?>
  <?php }?>
  <?php echo $_smarty_tpl->tpl_vars['matrix']->value->renderHeadSection();?>

<?php } ?>
</head>
<body>
<h1 class="title"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->pageTitle, ENT_QUOTES, 'UTF-8', true);?>
</h1>
<div class="workBack" style="overflow-y: auto;">

<?php echo $_smarty_tpl->getSubTemplate ("inc_result_tproject_tplan.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('arg_tproject_name'=>$_smarty_tpl->tpl_vars['gui']->value->tproject_name,'arg_tplan_name'=>$_smarty_tpl->tpl_vars['gui']->value->tplan_name), 0);?>
	

<?php if ($_smarty_tpl->tpl_vars['gui']->value->warning_msg==''){?>
	<?php if ($_smarty_tpl->tpl_vars['gui']->value->tableSet){?>
		<?php  $_smarty_tpl->tpl_vars['matrix'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['matrix']->_loop = false;
 $_smarty_tpl->tpl_vars['idx'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->tableSet; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['matrix']->key => $_smarty_tpl->tpl_vars['matrix']->value){
$_smarty_tpl->tpl_vars['matrix']->_loop = true;
 $_smarty_tpl->tpl_vars['idx']->value = $_smarty_tpl->tpl_vars['matrix']->key;
?>
			<?php $_smarty_tpl->tpl_vars['tableID'] = new Smarty_variable("table_".((string)$_smarty_tpl->tpl_vars['idx']->value), null, 0);?>
   			<?php echo $_smarty_tpl->tpl_vars['matrix']->value->renderBodySection($_smarty_tpl->tpl_vars['tableID']->value);?>

		<?php } ?>
		
		<br />
		<p class="italic"><?php echo $_smarty_tpl->tpl_vars['labels']->value['testCasesWithoutTester_info'];?>
</p>
		<br />
		
		<?php echo $_smarty_tpl->tpl_vars['labels']->value['generated_by_TestLink_on'];?>
 <?php echo smarty_modifier_date_format(time(),$_smarty_tpl->tpl_vars['gsmarty_timestamp_format']->value);?>

		
	<?php }else{ ?>
		<h2><?php echo $_smarty_tpl->tpl_vars['labels']->value['no_testcases_without_tester'];?>
</h2>
	<?php }?>
<?php }else{ ?>
	<br />
    <?php echo $_smarty_tpl->tpl_vars['gui']->value->warning_msg;?>

<?php }?>
</div>
</body>
</html><?php }} ?>