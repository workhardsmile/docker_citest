<?php /* Smarty version Smarty-3.1.13, created on 2016-09-05 11:42:56
         compiled from "/var/www/testlink-1.9.14/gui/templates/execute/getExecNotes.tpl" */ ?>
<?php /*%%SmartyHeaderCode:185426953557cce9c09e7fc9-87810294%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bc9dbb7cd31057433130787ca7cc0926167be2e0' => 
    array (
      0 => '/var/www/testlink-1.9.14/gui/templates/execute/getExecNotes.tpl',
      1 => 1427533464,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '185426953557cce9c09e7fc9-87810294',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'webeditorType' => 0,
    'readonly' => 0,
    'webeditorCfg' => 0,
    'notes' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_57cce9c0a215b1_95825361',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57cce9c0a215b1_95825361')) {function content_57cce9c0a215b1_95825361($_smarty_tpl) {?>
<html>
<head>
</head>
<body>
<?php if ($_smarty_tpl->tpl_vars['webeditorType']->value=='none'){?>
<textarea <?php echo $_smarty_tpl->tpl_vars['readonly']->value;?>
 name="notes" cols="<?php echo $_smarty_tpl->tpl_vars['webeditorCfg']->value['cols'];?>
" 
          rows="<?php echo $_smarty_tpl->tpl_vars['webeditorCfg']->value['rows'];?>
" style="background:transparent;">
<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['notes']->value, ENT_QUOTES, 'UTF-8', true);?>

</textarea>
<?php }else{ ?>
<?php echo $_smarty_tpl->tpl_vars['notes']->value;?>

<?php }?>
</body>
</html><?php }} ?>