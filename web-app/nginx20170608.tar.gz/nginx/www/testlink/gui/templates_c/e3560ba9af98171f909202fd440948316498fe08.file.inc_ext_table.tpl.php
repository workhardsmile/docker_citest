<?php /* Smarty version Smarty-3.1.13, created on 2017-06-05 11:56:52
         compiled from "/var/www/testlink/gui/templates/inc_ext_table.tpl" */ ?>
<?php /*%%SmartyHeaderCode:137750695934d684b88b13-43580628%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e3560ba9af98171f909202fd440948316498fe08' => 
    array (
      0 => '/var/www/testlink/gui/templates/inc_ext_table.tpl',
      1 => 1491911777,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '137750695934d684b88b13-43580628',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'tlImages' => 0,
    'labels' => 0,
    'gui' => 0,
    'matrix' => 0,
    'tableID' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5934d684c62620_00051965',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5934d684c62620_00051965')) {function content_5934d684c62620_00051965($_smarty_tpl) {?>



<?php echo lang_get_smarty(array('var'=>"labels",'s'=>"expand_collapse_groups, show_all_columns,
                          show_all_columns_tooltip, default_state, multisort, multisort_tooltip,
                          multisort_button_tooltip, button_refresh, btn_reset_filters, caption_nav_filters"),$_smarty_tpl);?>


 <script type="text/javascript"> 
var checkedImg = "<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['checked'];?>
";
 </script> 


<script type="text/javascript" src="gui/javascript/ext_extensions.js" language="javascript"></script>
<script type="text/javascript">

/*
 statusRenderer() 
 translate this code to a localized string and applies formatting
*/
function statusRenderer(item)
{
  item.cssClass = item.cssClass || "";
  return "<span class=\""+item.cssClass+"\">" + item.text + "</span>";
}

/*
 statusCompare() 
 handles the sorting order by status. 
 It maps a status code to a number. 
 The statuses are then sorted by comparing those numbers.
 WARNING: Global coupling
          uses variable status_code_order
*/
function statusCompare(item)
{
  var order=0;
  order = status_code_order[item.value];
  if( order == undefined )
  {
    alert('Configuration Issue - test case execution status code: ' + val + ' is not configured ');
    order = -1;
  }
  return order;
}

function priorityRenderer(val)
{
  return prio_code_label[val];
}

function importanceRenderer(val)
{
  return importance_code_label[val];
}

/* Unfortunately global coupling is needed to get the image */
function oneZeroImageRenderer(val)
{
  if(val == 1)
  {
    return '<img src="' + checkedImg + '" />';
  }
  else
  {
    return '';
  }
}

 

function columnWrap(val)
{
  return '<div style="white-space:normal !important; -moz-user-select: text; -webkit-user-select: text;">'+ val +'</div>';
}

// Functions for MultiSort
function createSorterButton(config, table) 
{
  config = config || {};
  Ext.applyIf(config, {
    listeners: {
      "click": function(button, e) {
        if(e.shiftKey == true) 
        {
          button.destroy();
          doSort(table);
        } 
        else
        {
          updateButtons(button, table, true);
        }
      }
    },
    iconCls: 'tbar-sort-' + config.sortData.direction.toLowerCase(),
    tooltip: '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['multisort_button_tooltip'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
',
    tooltipType: 'title',
    multisort: 'yes',
    reorderable: true
  });
  
  return new Ext.Button(config);
};
    
function updateButtons(button,table,changeDirection){
	sortData = button.sortData;
	iconCls = button.iconCls;
	
	if (sortData != undefined) {
		if (changeDirection != false) {
			button.sortData.direction = button.sortData.direction.toggle('ASC','DESC');
			button.setIconClass(button.iconCls.toggle('tbar-sort-asc', 'tbar-sort-desc'));
		}
	}
	store[table].clearFilter();
	doSort(table);
}

function doSort(table){
	sorters = getSorters(table);
	store[table].sort(sorters, 'ASC');
}

function getSorters(table) {
var sorters = [];
	tbar = grid[table].getTopToolbar();
	Ext.each(tbar.find('multisort', 'yes'), function(button) {
		sorters.push(button.sortData);
	}, this);
	return sorters;
}
//End Functions for MultiSort

Ext.onReady(function() {

  Ext.QuickTips.init();
	Ext.state.Manager.setProvider(new Ext.ux.JsonCookieProvider());
	<?php  $_smarty_tpl->tpl_vars['matrix'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['matrix']->_loop = false;
 $_smarty_tpl->tpl_vars['idx'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->tableSet; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['matrix']->key => $_smarty_tpl->tpl_vars['matrix']->value){
$_smarty_tpl->tpl_vars['matrix']->_loop = true;
 $_smarty_tpl->tpl_vars['idx']->value = $_smarty_tpl->tpl_vars['matrix']->key;
?>
		<?php $_smarty_tpl->tpl_vars['tableID'] = new Smarty_variable($_smarty_tpl->tpl_vars['matrix']->value->tableID, null, 0);?>

		store['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'] = new Ext.data.GroupingStore({
			reader: new Ext.data.ArrayReader({},
				fields['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'])
				<?php if ($_smarty_tpl->tpl_vars['matrix']->value->groupByColumn>=0){?>
					,groupField: '<?php echo $_smarty_tpl->tpl_vars['matrix']->value->groupByColumn;?>
'
				<?php }?>
				<?php if (!is_null($_smarty_tpl->tpl_vars['matrix']->value->sortByColumn)){?>
					,sortInfo:{field:'<?php echo $_smarty_tpl->tpl_vars['matrix']->value->sortByColumn;?>
',direction:'<?php echo $_smarty_tpl->tpl_vars['matrix']->value->sortDirection;?>
'}
				<?php }?>
			});
		store['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'].loadData(tableData['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
']);
			
		grid['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'] = new Ext.ux.SlimGridPanel({
			id: '<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
',
			store: store['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'],
			<?php if (!$_smarty_tpl->tpl_vars['matrix']->value->storeTableState){?>
				stateful: false,
			<?php }?>
			stripeRows: false,

			// init grid plugins
			plugins: [
				//init filter plugin
				filters = new Ext.ux.grid.GridFilters({
					// set to local filtering (on client side)
					local: true,
					showMenu: true,
					menuFilterText: '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['caption_nav_filters'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
'
				})
			],
			
			
			//show toolbar
			<?php if ($_smarty_tpl->tpl_vars['matrix']->value->showToolbar){?>
			tbar: tbar = new Ext.ux.TableToolbar({
				table_id: '<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
',
				showExpandCollapseGroupsButton: <?php echo json_encode($_smarty_tpl->tpl_vars['matrix']->value->toolbarExpandCollapseGroupsButton);?>
,
				showAllColumnsButton: <?php echo json_encode($_smarty_tpl->tpl_vars['matrix']->value->toolbarShowAllColumnsButton);?>
,
				<?php if ($_smarty_tpl->tpl_vars['matrix']->value->toolbarDefaultStateButton&&$_smarty_tpl->tpl_vars['matrix']->value->showToolbar&&$_smarty_tpl->tpl_vars['matrix']->value->storeTableState){?>
				showDefaultStateButton: true,
				<?php }else{ ?>
				showDefaultStateButton: false,
				<?php }?>
				showRefreshButton: <?php echo json_encode($_smarty_tpl->tpl_vars['matrix']->value->toolbarRefreshButton);?>
,

				labels: {
					button_refresh: '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['button_refresh'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
',
					default_state:  '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['default_state'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
',
					expand_collapse_groups: '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['expand_collapse_groups'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
',
					show_all_columns: '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['show_all_columns'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
',
					show_all_columns_tooltip: '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['show_all_columns_tooltip'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
'
				}
				//init plugins for multisort
				<?php if ($_smarty_tpl->tpl_vars['matrix']->value->allowMultiSort){?>
					// minor syntax error causing problems on IE6
					,plugins: [
						reorderer = new Ext.ux.ToolbarReorderer(),
						droppable = new Ext.ux.ToolbarDroppable({
						
							createItem: function(data) {
								var column = this.getColumnFromDragDrop(data);
								return createSorterButton({
									text    : column.header,
									sortData: {
										field: column.dataIndex,
										direction: "DESC"
									}
								}, '<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
');
							},

							canDrop: function(dragSource, event, data) {
								var sorters = getSorters('<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'),
                					column  = this.getColumnFromDragDrop(data);

								for (var i=0; i < sorters.length; i++) {
									if (sorters[i].field == column.dataIndex) return false;
								}

								return true;
							},
							
							//after multisort buttons changed sort data again 
							afterLayout: function () {
								doSort('<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
');
							},

							getColumnFromDragDrop: function(data) {
								var index    = data.header.cellIndex,
								colModel = grid['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'].colModel,
								column   = colModel.getColumnById(colModel.getColumnId(index));

								return column;
							}
						})
					],  //END plugins
					items: [], //necessary line as otherwise plugins will throw an error
					listeners: {
						scope    : this,
						reordered: function(button) {
							updateButtons(button,'<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
', false);
						}
					}
				<?php }?> // end plugins for multisort
			}), // END tbar
			<?php }?> // ENDIF showtoolbar
			
      listeners: {
      <?php if ($_smarty_tpl->tpl_vars['matrix']->value->allowMultiSort&&$_smarty_tpl->tpl_vars['matrix']->value->showToolbar){?>
        scope: this,
        render: function() {
          dragProxy = grid['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'].getView().columnDrag;
          ddGroup = dragProxy.ddGroup;
          droppable.addDDGroup(ddGroup);
        }
      <?php }?>
      }, // END listeners

      view: new Ext.grid.GroupingView({
        <?php echo $_smarty_tpl->tpl_vars['matrix']->value->getGridViewConfig();?>

      }), // END view
      
      columns: columnData['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
']
      <?php echo $_smarty_tpl->tpl_vars['matrix']->value->getGridSettings();?>

    }); // END grid

		// Export Button
		<?php if ($_smarty_tpl->tpl_vars['matrix']->value->showExportButton&&$_smarty_tpl->tpl_vars['matrix']->value->showToolbar){?>
			tbar.add(new Ext.ux.Exporter.Button({
				component: grid['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'],
				store: store['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
']
			}));
		<?php }?>
		
		// add button to reset filters
		// TODO : show only as active if at least 1 column is filtered
		<?php if ($_smarty_tpl->tpl_vars['matrix']->value->toolbarResetFiltersButton&&$_smarty_tpl->tpl_vars['matrix']->value->showToolbar){?>
			tbar.add({
				text: '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['btn_reset_filters'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
',
				iconCls: 'tbar-reset-filters',
				handler: function() {
					grid['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'].filters.clearFilters();
				}
			});
		<?php }?>

		//MULTISORT
		<?php if ($_smarty_tpl->tpl_vars['matrix']->value->allowMultiSort&&$_smarty_tpl->tpl_vars['matrix']->value->showToolbar){?>
			
			//add button seperator
			tbar.add({
				xtype: 'tbseparator'
			});
			
			//add multisort text
			tbar.add({
				handleMouseEvents: false,
				iconCls: 'tbar-info',
				iconAlign: 'right',
				text: '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['multisort'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
',
				tooltip: '<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['multisort_tooltip'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
',
				tooltipType: 'title'
			});
		<?php }?>
		//END MULTISORT
		
		//render grid
		grid['<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
'].render('<?php echo $_smarty_tpl->tpl_vars['tableID']->value;?>
_target');
	<?php } ?>

}); // END Ext.onReady
</script><?php }} ?>