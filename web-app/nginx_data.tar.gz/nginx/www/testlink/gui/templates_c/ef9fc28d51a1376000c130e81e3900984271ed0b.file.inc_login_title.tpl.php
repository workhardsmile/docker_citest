<?php /* Smarty version Smarty-3.1.13, created on 2017-04-12 00:11:50
         compiled from "/var/www/testlink/gui/templates/inc_login_title.tpl" */ ?>
<?php /*%%SmartyHeaderCode:35910832758ed0046e7caa3-28484845%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ef9fc28d51a1376000c130e81e3900984271ed0b' => 
    array (
      0 => '/var/www/testlink/gui/templates/inc_login_title.tpl',
      1 => 1491911777,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '35910832758ed0046e7caa3-28484845',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'tlCfg' => 0,
    'tlVersion' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_58ed0046e93358_31595969',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58ed0046e93358_31595969')) {function content_58ed0046e93358_31595969($_smarty_tpl) {?>
<div class="login_title">
<p><img alt="Company logo" title="logo" src="<?php echo @constant('TL_THEME_IMG_DIR');?>
<?php echo $_smarty_tpl->tpl_vars['tlCfg']->value->logo_login;?>
" />
   <br /><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['tlVersion']->value, ENT_QUOTES, 'UTF-8', true);?>
</p>
</div><?php }} ?>