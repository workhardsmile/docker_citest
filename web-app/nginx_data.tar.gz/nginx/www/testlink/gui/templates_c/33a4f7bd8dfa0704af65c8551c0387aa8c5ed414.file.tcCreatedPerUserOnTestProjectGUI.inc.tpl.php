<?php /* Smarty version Smarty-3.1.13, created on 2017-04-12 09:53:05
         compiled from "/var/www/testlink/gui/templates/results/tcCreatedPerUserOnTestProjectGUI.inc.tpl" */ ?>
<?php /*%%SmartyHeaderCode:32608507058ed8881b2add5-79528211%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '33a4f7bd8dfa0704af65c8551c0387aa8c5ed414' => 
    array (
      0 => '/var/www/testlink/gui/templates/results/tcCreatedPerUserOnTestProjectGUI.inc.tpl',
      1 => 1491911777,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32608507058ed8881b2add5-79528211',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'gui' => 0,
    'labels' => 0,
    'user' => 0,
    'login' => 0,
    'gsmarty_datepicker_format' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_58ed8881bccbf4_19689380',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58ed8881bccbf4_19689380')) {function content_58ed8881bccbf4_19689380($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_select_time')) include '/var/www/testlink/third_party/smarty3/libs/plugins/function.html_select_time.php';
?>
    <div class="workBack">
      <form action="lib/results/tcCreatedPerUserOnTestProject.php" method="post">
        <input type="hidden" id="tproject_id" name="tproject_id" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->tproject_id;?>
" />
        <input type="hidden" id="do_action" name="do_action" value="result" />
        <div>
          <table class="simple" style="text-align: center; margin-left: 0px;">
            <tr>
                <th width="34%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['th_user'];?>
</th>
                <th width="33%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['th_start_time'];?>
</th>
                <th width="33%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['th_end_time'];?>
</th>
            </tr>
            <tr>
            	<td align="center">
                <select name="user_id">
                  <?php  $_smarty_tpl->tpl_vars['login'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['login']->_loop = false;
 $_smarty_tpl->tpl_vars['user'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->users->items; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['login']->key => $_smarty_tpl->tpl_vars['login']->value){
$_smarty_tpl->tpl_vars['login']->_loop = true;
 $_smarty_tpl->tpl_vars['user']->value = $_smarty_tpl->tpl_vars['login']->key;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['user']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['user']->value==$_smarty_tpl->tpl_vars['gui']->value->user_id){?> selected="selected" <?php }?>><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['login']->value, ENT_QUOTES, 'UTF-8', true);?>
</option>
                  <?php } ?>
		  	        </select>
                </td>
                <td align="center">
                   <table border='0'>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['date'];?>
</td>
                        <td>
                            <input type="text" 
                                   name="selected_start_date" id="selected_start_date" 
                                   value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->selected_start_date;?>
" 
                                   onclick="showCal('selected_start_date-cal','selected_start_date','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" 
                                   readonly="readonly" />
                            <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_calender'];?>
" src="<?php echo @constant('TL_THEME_IMG_DIR');?>
/calendar.gif"
                                 onclick="showCal('selected_start_date-cal','selected_start_date','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" />
                            <div id="selected_start_date-cal" style="position:absolute;width:240px;left:300px;z-index:1;"></div>
                        </td>
                    </tr>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['hour'];?>
</td>
                        <td align='left'><?php echo smarty_function_html_select_time(array('prefix'=>"start_",'display_minutes'=>false,'time'=>$_smarty_tpl->tpl_vars['gui']->value->selected_start_time,'display_seconds'=>false,'use_24_hours'=>true),$_smarty_tpl);?>

                        </td>
                    </tr>
                  </table>
                </td>
                <td align="center">
                   <table border='0'>
                       <tr>
                           <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['date'];?>
</td>
                           <td>
                                <input type="text" 
                                       name="selected_end_date" id="selected_end_date" 
                                       value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->selected_end_date;?>
" 
                                       onclick="showCal('selected_end_date-cal','selected_end_date','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" readonly />
                                <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_calender'];?>
" src="<?php echo @constant('TL_THEME_IMG_DIR');?>
/calendar.gif"
                                     onclick="showCal('selected_end_date-cal','selected_end_date','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" >
                                <div id="selected_end_date-cal" style="position:absolute;width:240px;left:300px;z-index:1;"></div>
                           </td>
                       </tr>
                       <tr>
                           <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['hour'];?>
</td>
                           <td align='left'><?php echo smarty_function_html_select_time(array('prefix'=>"end_",'display_minutes'=>false,'time'=>$_smarty_tpl->tpl_vars['gui']->value->selected_end_time,'display_seconds'=>false,'use_24_hours'=>true),$_smarty_tpl);?>
</td>
                       </tr>
                   </table>
                </td>
            </tr>
          </table>
        </div>
        <div>
        	<input type="submit" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['submit_query'];?>
"/>
        </div>
      </form>
    </div><?php }} ?>