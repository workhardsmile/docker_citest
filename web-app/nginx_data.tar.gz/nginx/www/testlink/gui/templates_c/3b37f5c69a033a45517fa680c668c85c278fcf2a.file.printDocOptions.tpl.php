<?php /* Smarty version Smarty-3.1.13, created on 2016-09-05 11:32:09
         compiled from "/var/www/testlink-1.9.14/gui/templates/results/printDocOptions.tpl" */ ?>
<?php /*%%SmartyHeaderCode:68651672857cce739520e37-63376870%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3b37f5c69a033a45517fa680c668c85c278fcf2a' => 
    array (
      0 => '/var/www/testlink-1.9.14/gui/templates/results/printDocOptions.tpl',
      1 => 1434817944,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '68651672857cce739520e37-63376870',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'gui' => 0,
    'docTestPlanId' => 0,
    'labels' => 0,
    'build_id' => 0,
    'buildObj' => 0,
    'docType' => 0,
    'selFormat' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_57cce7395e5db2_76395643',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57cce7395e5db2_76395643')) {function content_57cce7395e5db2_76395643($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_options')) include '/var/www/testlink-1.9.14/third_party/smarty3/libs/plugins/function.html_options.php';
?>
<?php echo lang_get_smarty(array('var'=>"labels",'s'=>'doc_opt_title,doc_opt_guide,tr_td_show_as,check_uncheck_all_options,build,builds,onlywithuser'),$_smarty_tpl);?>


<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>"yes"), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_ext_js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('bResetEXTCss'=>1), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_jsCheckboxes.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<?php if ($_smarty_tpl->tpl_vars['gui']->value->ajaxTree->loadFromChildren){?>
  <script type="text/javascript">
  /* space after { and before } to signal to smarty that is JS => do not process */
  treeCfg = { tree_div_id:'tree_div',root_name:"",root_id:0,root_href:"",
              loader:"", enableDD:false, dragDropBackEndUrl:'',children:"" };
  </script>
  <script type="text/javascript">
  treeCfg.root_name = '<?php echo strtr($_smarty_tpl->tpl_vars['gui']->value->ajaxTree->root_node->name, array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
';
  treeCfg.root_id = <?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->root_node->id;?>
;
  treeCfg.root_href = '<?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->root_node->href;?>
';
  treeCfg.children = <?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->children;?>

  treeCfg.cookiePrefix = '<?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->cookiePrefix;?>
';
  </script>
  <script type="text/javascript" src='gui/javascript/execTree.js'></script>

<?php }else{ ?>
  <script type="text/javascript">
  treeCfg = { tree_div_id:'tree_div',root_name:"",root_id:0,root_href:"",
               loader:"", enableDD:false, dragDropBackEndUrl:'' };
  </script>
  <script type="text/javascript">
  treeCfg.loader = '<?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->loader;?>
';
  treeCfg.root_name = '<?php echo strtr($_smarty_tpl->tpl_vars['gui']->value->ajaxTree->root_node->name, array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
';
  treeCfg.root_id = <?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->root_node->id;?>
;
  treeCfg.root_href = '<?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->root_node->href;?>
';
  treeCfg.enableDD = '<?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->dragDrop->enabled;?>
';
  treeCfg.dragDropBackEndUrl = '<?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->dragDrop->BackEndUrl;?>
';
  treeCfg.cookiePrefix = '<?php echo $_smarty_tpl->tpl_vars['gui']->value->ajaxTree->cookiePrefix;?>
';
  </script>
  <script type="text/javascript" src='gui/javascript/treebyloader.js'></script>
<?php }?> 

<?php if ($_smarty_tpl->tpl_vars['gui']->value->buildInfoSet!=''){?>
<script>
jQuery( document ).ready(function() {
jQuery(".chosen-select").chosen({ width: "100%" });
});
</script>
<?php }?>

</head>

<body>
<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['gui']->value->mainTitle;?>
 
                  <?php if ($_smarty_tpl->tpl_vars['gui']->value->showHelpIcon){?><?php echo $_smarty_tpl->getSubTemplate ("inc_help.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('helptopic'=>"hlp_generateDocOptions",'show_help_icon'=>true), 0);?>
<?php }?>
                </h1>


<div style="margin: 10px; <?php if (!$_smarty_tpl->tpl_vars['gui']->value->showOptions){?>display:none;<?php }?>" >

<form method="GET" id="printDocOptions" name="printDocOptions"
      action="lib/results/printDocument.php?type=<?php echo $_smarty_tpl->tpl_vars['gui']->value->doc_type;?>
">

  <input type="hidden" name="docTestPlanId" value="<?php echo $_smarty_tpl->tpl_vars['docTestPlanId']->value;?>
" />
  <input type="hidden" name="toggle_memory" id="toggle_memory"  value="0" />


  <?php if ($_smarty_tpl->tpl_vars['gui']->value->buildInfoSet!=''){?>
   <table>
    <tr>
     <td><label for="build"> <?php echo $_smarty_tpl->tpl_vars['labels']->value['build'];?>
</label></td>
     <td style="width:100px"> 
      <select class="chosen-select" name="build_id" id="build_id" 
              data-placeholder="<?php echo $_smarty_tpl->tpl_vars['labels']->value['builds'];?>
">
        <?php  $_smarty_tpl->tpl_vars['buildObj'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['buildObj']->_loop = false;
 $_smarty_tpl->tpl_vars['build_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->buildInfoSet; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['buildObj']->key => $_smarty_tpl->tpl_vars['buildObj']->value){
$_smarty_tpl->tpl_vars['buildObj']->_loop = true;
 $_smarty_tpl->tpl_vars['build_id']->value = $_smarty_tpl->tpl_vars['buildObj']->key;
?>
          <option value="<?php echo $_smarty_tpl->tpl_vars['build_id']->value;?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['buildObj']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</option>
        <?php } ?>
      </select>
     </td>
     <td style="width:20px">&nbsp;</td>
     <td><label for="with_user_assignment"><?php echo $_smarty_tpl->tpl_vars['labels']->value['onlywithuser'];?>
</label></td>
     <td><input type="checkbox" name="with_user_assignment" 
                id="with_user_assignment"></td>
    </tr>
   </table>
  <?php }?>

  
  <table class="smallGrey" id="optionsContainer" name="optionsContainer">
    <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['number'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['number']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['name'] = 'number';
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['gui']->value->outputOptions) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['number']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['number']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['number']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['number']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['number']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['number']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['number']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['number']['total']);
?>
    <tr style="margin: 10px; <?php if (!$_smarty_tpl->tpl_vars['gui']->value->showOptionsCheckBoxes){?>display:none;<?php }?>">
      <td><?php echo $_smarty_tpl->tpl_vars['gui']->value->outputOptions[$_smarty_tpl->getVariable('smarty')->value['section']['number']['index']]['description'];?>
</td>
      <td>
        <input type="checkbox" name="<?php echo $_smarty_tpl->tpl_vars['gui']->value->outputOptions[$_smarty_tpl->getVariable('smarty')->value['section']['number']['index']]['value'];?>
" id="cb<?php echo $_smarty_tpl->tpl_vars['gui']->value->outputOptions[$_smarty_tpl->getVariable('smarty')->value['section']['number']['index']]['value'];?>
"
        <?php if ($_smarty_tpl->tpl_vars['gui']->value->outputOptions[$_smarty_tpl->getVariable('smarty')->value['section']['number']['index']]['checked']=='y'){?>checked="checked"<?php }?>/>
      </td>
    </tr>
    <?php endfor; endif; ?>

    <tr style="margin: 10px;<?php if (!$_smarty_tpl->tpl_vars['gui']->value->showOptionsCheckBoxes){?>display:none;<?php }?>">
     <td><input type="button" id="toogleOptions" name="toogleOptions"
                onclick='cs_all_checkbox_in_div("optionsContainer","cb","toggle_memory");'
                value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['check_uncheck_all_options'];?>
" /> </td>
    </tr>

    
    <tr>
    <?php if ($_smarty_tpl->tpl_vars['docType']->value=='testspec'||$_smarty_tpl->tpl_vars['docType']->value=='reqspec'){?>
      <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['tr_td_show_as'];?>
</td>
      <td>
        <select id="format" name="format">
          <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->outputFormat,'selected'=>$_smarty_tpl->tpl_vars['selFormat']->value),$_smarty_tpl);?>

        </select>
      </td>
    <?php }else{ ?>
      <td><input type="hidden" id="format" name="format" value="<?php echo $_smarty_tpl->tpl_vars['selFormat']->value;?>
" /></td>
    <?php }?>
    </tr>
  </table>
  <br> 
  <p><?php echo $_smarty_tpl->tpl_vars['labels']->value['doc_opt_guide'];?>
<br /></p>

</form>
</div>

<div id="tree_div" style="overflow:auto; height:100%;border:1px solid #c3daf9;"></div>

</body>
</html><?php }} ?>